// TextToSlides Application - Main JavaScript Logic
class TextToSlidesApp {
    constructor() {
        this.currentStep = 1;
        this.maxSteps = 4;
        this.appState = {
            content: '',
            guidance: '',
            llmProvider: null,
            llmModel: null,
            apiKey: '',
            template: null,
            templateAnalysis: null,
            generatedPresentation: null
        };

        // Application data from JSON
        this.llmProviders = [
            {
                name: "OpenAI",
                id: "openai",
                models: ["gpt-4", "gpt-4-turbo", "gpt-3.5-turbo"],
                api_base: "https://api.openai.com/v1",
                default_model: "gpt-4-turbo"
            },
            {
                name: "Anthropic",
                id: "anthropic", 
                models: ["claude-3-5-sonnet-20241022", "claude-3-haiku-20240307"],
                api_base: "https://api.anthropic.com/v1",
                default_model: "claude-3-5-sonnet-20241022"
            },
            {
                name: "Google Gemini",
                id: "gemini",
                models: ["gemini-1.5-pro", "gemini-1.5-flash"],
                api_base: "https://generativelanguage.googleapis.com/v1",
                default_model: "gemini-1.5-pro"
            }
        ];

        this.guidanceExamples = [
            "Turn into an investor pitch deck",
            "Create a professional business presentation", 
            "Make it suitable for academic presentation",
            "Format as a training workshop",
            "Structure as a project proposal",
            "Design for executive summary",
            "Convert to educational content",
            "Format as a research presentation"
        ];

        this.processingSteps = [
            "Analyzing input text",
            "Extracting template styles", 
            "Generating slide structure",
            "Creating content outlines",
            "Applying template formatting",
            "Building final presentation"
        ];

        this.initialize();
    }

    initialize() {
        console.log('Initializing TextToSlides application...');
        this.setupEventListeners();
        this.populateFormElements();
        this.updateStepVisibility();
        this.setupFileUpload();
        this.showWelcomeMessage();
        console.log('Application initialized successfully');
    }

    showWelcomeMessage() {
        setTimeout(() => {
            this.showAlert('info', 'Welcome to TextToSlides! Follow the steps to transform your text into a beautiful PowerPoint presentation.', true);
        }, 500);
    }

    setupEventListeners() {
        console.log('Setting up event listeners...');

        // Wait for DOM to be ready
        this.waitForElements().then(() => {
            this.bindEventListeners();
        });
    }

    async waitForElements() {
        // Wait for elements to be available
        const checkElements = () => {
            const requiredElements = [
                'content-input', 'next-to-step-2', 'llm-provider', 
                'back-to-step-1', 'next-to-step-3', 'upload-area'
            ];
            
            return requiredElements.every(id => document.getElementById(id) !== null);
        };

        let attempts = 0;
        while (!checkElements() && attempts < 10) {
            await this.delay(100);
            attempts++;
        }

        console.log('Elements ready after', attempts, 'attempts');
    }

    bindEventListeners() {
        console.log('Binding event listeners...');

        // Step 1 - Content Input
        this.bindElement('content-input', 'input', () => this.handleContentInput());
        this.bindElement('guidance-input', 'input', () => this.handleGuidanceInput());
        this.bindElement('next-to-step-2', 'click', (e) => {
            e.preventDefault();
            console.log('Next to step 2 button clicked');
            this.goToStep(2);
        });

        // Step 2 - AI Configuration  
        this.bindElement('llm-provider', 'change', () => this.handleProviderChange());
        this.bindElement('llm-model', 'change', () => this.handleModelChange());
        this.bindElement('api-key', 'input', () => this.handleApiKeyInput());
        this.bindElement('toggle-api-key', 'click', () => this.toggleApiKeyVisibility());
        this.bindElement('test-api', 'click', () => this.testApiConnection());
        this.bindElement('back-to-step-1', 'click', (e) => {
            e.preventDefault();
            console.log('Back to step 1 button clicked');
            this.goToStep(1);
        });
        this.bindElement('next-to-step-3', 'click', (e) => {
            e.preventDefault();
            console.log('Next to step 3 button clicked');
            this.goToStep(3);
        });

        // Step 3 - Template Upload
        this.bindElement('back-to-step-2', 'click', (e) => {
            e.preventDefault();
            console.log('Back to step 2 button clicked');
            this.goToStep(2);
        });
        this.bindElement('next-to-step-4', 'click', (e) => {
            e.preventDefault();
            console.log('Next to step 4 button clicked');
            this.startGeneration();
        });
        this.bindElement('remove-template', 'click', () => this.removeTemplate());

        // Step 4 - Generation
        this.bindElement('download-presentation', 'click', () => this.downloadPresentation());
        this.bindElement('start-over', 'click', () => this.startOver());
        this.bindElement('retry-generation', 'click', () => this.startGeneration());
        this.bindElement('back-to-config', 'click', () => this.goToStep(2));

        // Progress step navigation
        document.querySelectorAll('.step[data-step]').forEach((step) => {
            step.addEventListener('click', (e) => {
                e.preventDefault();
                const stepNumber = parseInt(step.getAttribute('data-step'));
                console.log('Progress step clicked:', stepNumber);
                if (stepNumber >= 1 && stepNumber <= this.maxSteps) {
                    this.goToStep(stepNumber);
                }
            });
        });

        // Make progress steps clickable
        document.querySelectorAll('.step').forEach((step, index) => {
            if (!step.hasAttribute('data-step')) {
                step.setAttribute('data-step', index + 1);
            }
            step.style.cursor = 'pointer';
            step.addEventListener('click', (e) => {
                e.preventDefault();
                const stepNumber = index + 1;
                console.log('Progress step', stepNumber, 'clicked');
                this.goToStep(stepNumber);
            });
        });

        // Guidance examples
        this.setupGuidanceExamples();

        console.log('All event listeners bound successfully');
    }

    bindElement(elementId, eventType, handler) {
        const element = document.getElementById(elementId);
        if (element) {
            element.addEventListener(eventType, handler);
            console.log(`Bound ${eventType} listener to ${elementId}`);
        } else {
            console.warn(`Element ${elementId} not found for binding`);
        }
    }

    setupGuidanceExamples() {
        const examplesContainer = document.getElementById('guidance-examples');
        if (!examplesContainer) {
            console.log('Guidance examples container not found');
            return;
        }

        examplesContainer.innerHTML = ''; // Clear existing content
        this.guidanceExamples.forEach(example => {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'btn btn--sm';
            btn.textContent = example;
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                const guidanceInput = document.getElementById('guidance-input');
                if (guidanceInput) {
                    guidanceInput.value = example;
                    this.handleGuidanceInput();
                }
            });
            examplesContainer.appendChild(btn);
        });
        console.log('Guidance examples setup complete');
    }

    populateFormElements() {
        // Populate LLM providers
        const providerSelect = document.getElementById('llm-provider');
        if (providerSelect) {
            // Clear existing options except first
            providerSelect.innerHTML = '<option value="">Select a provider...</option>';
            
            this.llmProviders.forEach(provider => {
                const option = document.createElement('option');
                option.value = provider.id;
                option.textContent = provider.name;
                providerSelect.appendChild(option);
            });
            console.log('LLM providers populated');
        }
    }

    // Step Navigation
    goToStep(stepNumber) {
        console.log(`=== NAVIGATION: Attempting to go to step ${stepNumber} from step ${this.currentStep} ===`);
        
        if (stepNumber < 1 || stepNumber > this.maxSteps) {
            console.log('Invalid step number:', stepNumber);
            return false;
        }
        
        // For navigation forward, validate current step (except for backward navigation)
        if (stepNumber > this.currentStep && !this.validateCurrentStep()) {
            console.log('Current step validation failed');
            return false;
        }

        // Update current step
        const previousStep = this.currentStep;
        this.currentStep = stepNumber;
        
        console.log(`Step changed from ${previousStep} to ${this.currentStep}`);
        
        // Update UI
        this.updateStepVisibility();
        this.updateProgressSteps();
        this.scrollToTop();
        
        console.log(`=== NAVIGATION COMPLETE: Successfully navigated to step ${stepNumber} ===`);
        return true;
    }

    validateCurrentStep() {
        console.log(`Validating step ${this.currentStep}`);
        switch (this.currentStep) {
            case 1:
                return this.validateStep1();
            case 2:
                return this.validateStep2();
            case 3:
                return this.validateStep3();
            default:
                return true;
        }
    }

    validateStep1() {
        const content = document.getElementById('content-input')?.value.trim();
        if (!content || content.length < 100) {
            this.showAlert('warning', 'Please enter at least 100 characters of content to generate a meaningful presentation.');
            return false;
        }
        this.appState.content = content;
        this.appState.guidance = document.getElementById('guidance-input')?.value.trim();
        console.log('Step 1 validated successfully');
        return true;
    }

    validateStep2() {
        const provider = document.getElementById('llm-provider')?.value;
        const model = document.getElementById('llm-model')?.value;
        const apiKey = document.getElementById('api-key')?.value.trim();

        if (!provider || !model || !apiKey) {
            this.showAlert('warning', 'Please configure all AI settings: provider, model, and API key.');
            return false;
        }

        this.appState.llmProvider = provider;
        this.appState.llmModel = model;
        this.appState.apiKey = apiKey;
        console.log('Step 2 validated successfully');
        return true;
    }

    validateStep3() {
        if (!this.appState.template) {
            this.showAlert('warning', 'Please upload a PowerPoint template to continue.');
            return false;
        }
        console.log('Step 3 validated successfully');
        return true;
    }

    updateStepVisibility() {
        console.log(`Updating step visibility: hiding all, showing step ${this.currentStep}`);
        
        // Hide all step contents
        for (let i = 1; i <= this.maxSteps; i++) {
            const stepContent = document.getElementById(`step-${i}`);
            if (stepContent) {
                stepContent.classList.remove('active');
                console.log(`Hidden step ${i}`);
            }
        }

        // Show current step
        const currentStepContent = document.getElementById(`step-${this.currentStep}`);
        if (currentStepContent) {
            currentStepContent.classList.add('active');
            console.log(`Showing step ${this.currentStep}`);
            
            // Force display for debugging
            currentStepContent.style.display = 'block';
        } else {
            console.error(`Step content not found for step ${this.currentStep}`);
        }
    }

    updateProgressSteps() {
        document.querySelectorAll('.step').forEach((step, index) => {
            const stepNumber = index + 1;
            step.classList.remove('active', 'completed');
            
            if (stepNumber === this.currentStep) {
                step.classList.add('active');
            } else if (stepNumber < this.currentStep) {
                step.classList.add('completed');
            }
        });
        console.log('Progress steps updated');
    }

    scrollToTop() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // Step 1: Content Input Handlers
    handleContentInput() {
        const contentInput = document.getElementById('content-input');
        const content = contentInput?.value || '';
        
        this.updateContentStats(content);
        this.updateNextButton('next-to-step-2', content.trim().length >= 100);
    }

    handleGuidanceInput() {
        // Just store the guidance, no validation needed
        const guidance = document.getElementById('guidance-input')?.value || '';
        this.appState.guidance = guidance;
    }

    updateContentStats(content) {
        const charCount = content.length;
        const wordCount = content.trim() ? content.trim().split(/\s+/).length : 0;
        const estimatedSlides = Math.max(1, Math.ceil(wordCount / 150)); // ~150 words per slide

        const charCountEl = document.getElementById('char-count');
        const wordCountEl = document.getElementById('word-count');
        const estimatedSlidesEl = document.getElementById('estimated-slides');

        if (charCountEl) charCountEl.textContent = `${charCount.toLocaleString()} characters`;
        if (wordCountEl) wordCountEl.textContent = `${wordCount.toLocaleString()} words`;
        if (estimatedSlidesEl) estimatedSlidesEl.textContent = `~${estimatedSlides} slides`;
    }

    // Step 2: AI Configuration Handlers
    handleProviderChange() {
        const providerSelect = document.getElementById('llm-provider');
        const modelSelect = document.getElementById('llm-model');
        const apiTestSection = document.getElementById('api-test-section');
        
        if (!providerSelect || !modelSelect) return;

        const selectedProvider = this.llmProviders.find(p => p.id === providerSelect.value);
        
        // Clear and populate model options
        modelSelect.innerHTML = '<option value="">Select a model...</option>';
        modelSelect.disabled = !selectedProvider;

        if (selectedProvider) {
            selectedProvider.models.forEach(model => {
                const option = document.createElement('option');
                option.value = model;
                option.textContent = model;
                if (model === selectedProvider.default_model) {
                    option.selected = true;
                }
                modelSelect.appendChild(option);
            });
            
            if (apiTestSection) apiTestSection.style.display = 'block';
        } else {
            if (apiTestSection) apiTestSection.style.display = 'none';
        }

        this.handleModelChange();
    }

    handleModelChange() {
        this.updateNextButton('next-to-step-3', this.isStep2Valid());
    }

    handleApiKeyInput() {
        this.updateNextButton('next-to-step-3', this.isStep2Valid());
    }

    isStep2Valid() {
        const provider = document.getElementById('llm-provider')?.value;
        const model = document.getElementById('llm-model')?.value;
        const apiKey = document.getElementById('api-key')?.value.trim();
        
        return provider && model && apiKey;
    }

    toggleApiKeyVisibility() {
        const apiKeyInput = document.getElementById('api-key');
        const toggleBtn = document.getElementById('toggle-api-key');
        
        if (!apiKeyInput || !toggleBtn) return;

        const isPassword = apiKeyInput.type === 'password';
        apiKeyInput.type = isPassword ? 'text' : 'password';
        toggleBtn.innerHTML = isPassword ? '<i class="bi bi-eye-slash"></i>' : '<i class="bi bi-eye"></i>';
    }

    async testApiConnection() {
        const testBtn = document.getElementById('test-api');
        const statusEl = document.getElementById('api-status');
        
        if (!testBtn || !statusEl) return;

        testBtn.disabled = true;
        testBtn.innerHTML = '<span class="spinner-border spinner-border-sm me-1"></span>Testing...';
        
        try {
            // Simulate API test
            await this.delay(2000);
            
            // In a real implementation, this would make an actual API call
            const success = Math.random() > 0.3; // 70% success rate for demo
            
            if (success) {
                statusEl.innerHTML = '<span class="status--success"><i class="bi bi-check-circle me-1"></i>Connection successful!</span>';
                this.showAlert('success', 'API connection test successful! You can proceed to the next step.');
            } else {
                statusEl.innerHTML = '<span class="status--error"><i class="bi bi-x-circle me-1"></i>Connection failed</span>';
                this.showAlert('danger', 'API connection test failed. Please check your API key and try again.');
            }
        } catch (error) {
            statusEl.innerHTML = '<span class="status--error"><i class="bi bi-x-circle me-1"></i>Test failed</span>';
            this.showAlert('danger', `API test error: ${error.message}`);
        } finally {
            testBtn.disabled = false;
            testBtn.innerHTML = '<i class="bi bi-check-circle me-1"></i>Test API Connection';
        }
    }

    // Step 3: File Upload Handlers
    setupFileUpload() {
        // Set up file upload after a small delay to ensure elements exist
        setTimeout(() => {
            this.initializeFileUpload();
        }, 100);
    }

    initializeFileUpload() {
        const uploadArea = document.getElementById('upload-area');
        const fileInput = document.getElementById('file-input');
        const browseBtn = document.getElementById('browse-files');

        if (!uploadArea || !fileInput) {
            console.log('Upload area or file input not found during setup');
            return;
        }

        // Click to browse
        if (browseBtn) {
            browseBtn.addEventListener('click', (e) => {
                e.preventDefault();
                fileInput.click();
            });
        }

        uploadArea.addEventListener('click', (e) => {
            // Only trigger if clicking on the upload area itself, not child elements
            if (e.target === uploadArea || e.target.closest('.upload-content')) {
                fileInput.click();
            }
        });

        // File input change
        fileInput.addEventListener('change', (e) => {
            const file = e.target.files?.[0];
            if (file) this.handleFileUpload(file);
        });

        // Drag and drop
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('dragover');
        });

        uploadArea.addEventListener('dragleave', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('dragover');
        });

        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('dragover');
            
            const file = e.dataTransfer.files?.[0];
            if (file) this.handleFileUpload(file);
        });

        console.log('File upload setup complete');
    }

    async handleFileUpload(file) {
        console.log('Handling file upload:', file.name);
        
        // Validate file
        if (!this.validateFile(file)) return;

        try {
            // Show upload progress
            this.showUploadProgress();
            
            // Simulate file processing
            await this.delay(1500);
            
            // Analyze template
            const analysis = await this.analyzeTemplate(file);
            
            this.appState.template = file;
            this.appState.templateAnalysis = analysis;
            
            this.showTemplatePreview(file, analysis);
            this.updateNextButton('next-to-step-4', true);
            
            this.showAlert('success', 'Template uploaded and analyzed successfully!');
        } catch (error) {
            this.showAlert('danger', `Error processing template: ${error.message}`);
        }
    }

    validateFile(file) {
        const maxSize = 50 * 1024 * 1024; // 50MB
        const allowedTypes = ['application/vnd.openxmlformats-officedocument.presentationml.presentation', 
                             'application/vnd.openxmlformats-officedocument.presentationml.template'];
        
        if (file.size > maxSize) {
            this.showAlert('danger', 'File size exceeds 50MB limit. Please choose a smaller file.');
            return false;
        }

        if (!allowedTypes.includes(file.type) && !file.name.match(/\.(pptx|potx)$/i)) {
            this.showAlert('danger', 'Invalid file type. Please upload a PowerPoint file (.pptx or .potx).');
            return false;
        }

        return true;
    }

    showUploadProgress() {
        const uploadArea = document.getElementById('upload-area');
        if (!uploadArea) return;

        uploadArea.innerHTML = `
            <div class="upload-content">
                <div class="spinner-border text-primary mb-3"></div>
                <h4>Processing template...</h4>
                <p>Analyzing styles, layouts, and assets</p>
            </div>
        `;
    }

    async analyzeTemplate(file) {
        // Simulate template analysis
        await this.delay(1000);
        
        // Mock analysis results
        return {
            slideCount: Math.floor(Math.random() * 10) + 5,
            colors: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F'],
            fonts: ['Calibri', 'Arial', 'Segoe UI'],
            layouts: ['Title Slide', 'Title and Content', 'Two Content', 'Section Header'],
            images: Math.floor(Math.random() * 5) + 2,
            hasTheme: true
        };
    }

    showTemplatePreview(file, analysis) {
        const uploadArea = document.getElementById('upload-area');
        const preview = document.getElementById('template-preview');
        
        if (!uploadArea || !preview) return;

        // Hide upload area and show preview
        uploadArea.style.display = 'none';
        preview.style.display = 'block';

        // Update template info
        const templateName = document.getElementById('template-name');
        const templateSize = document.getElementById('template-size');
        const templateSlides = document.getElementById('template-slides');

        if (templateName) templateName.textContent = file.name;
        if (templateSize) templateSize.textContent = this.formatFileSize(file.size);
        if (templateSlides) templateSlides.textContent = `${analysis.slideCount} slides`;

        // Update analysis
        const colorsEl = document.getElementById('template-colors');
        if (colorsEl) {
            colorsEl.innerHTML = analysis.colors.map(color => 
                `<div class="color-swatch" style="background-color: ${color}"></div>`
            ).join('');
        }

        const templateFonts = document.getElementById('template-fonts');
        const templateLayouts = document.getElementById('template-layouts');
        
        if (templateFonts) templateFonts.textContent = analysis.fonts.join(', ');
        if (templateLayouts) templateLayouts.textContent = analysis.layouts.join(', ');
    }

    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    removeTemplate() {
        this.appState.template = null;
        this.appState.templateAnalysis = null;
        
        const uploadArea = document.getElementById('upload-area');
        const preview = document.getElementById('template-preview');
        const fileInput = document.getElementById('file-input');
        
        if (uploadArea) uploadArea.style.display = 'block';
        if (preview) preview.style.display = 'none';
        if (fileInput) fileInput.value = '';
        
        // Reset upload area content
        if (uploadArea) {
            uploadArea.innerHTML = `
                <div class="upload-content">
                    <i class="bi bi-cloud-upload upload-icon"></i>
                    <h4>Drop your PowerPoint template here</h4>
                    <p>or <button type="button" class="btn-link" id="browse-files">browse files</button></p>
                    <div class="supported-formats">
                        <span class="format-badge">.PPTX</span>
                        <span class="format-badge">.POTX</span>
                    </div>
                </div>
            `;
            
            // Re-setup browse button
            const browseBtn = document.getElementById('browse-files');
            if (browseBtn) {
                browseBtn.addEventListener('click', (e) => {
                    e.preventDefault();
                    document.getElementById('file-input').click();
                });
            }
        }

        this.updateNextButton('next-to-step-4', false);
    }

    // Step 4: Generation Handlers
    async startGeneration() {
        if (!this.goToStep(4)) return;
        
        try {
            // Initialize progress
            this.initializeProgress();
            
            // Run generation steps
            for (let i = 0; i < this.processingSteps.length; i++) {
                await this.executeProcessingStep(i);
            }
            
            // Show completion
            this.showGenerationComplete();
            
        } catch (error) {
            this.showGenerationError(error.message);
        }
    }

    initializeProgress() {
        const progressList = document.getElementById('progress-list');
        const generationStats = document.getElementById('generation-stats');
        const generationComplete = document.getElementById('generation-complete');
        const generationError = document.getElementById('generation-error');

        if (generationStats) generationStats.style.display = 'none';
        if (generationComplete) generationComplete.style.display = 'none';
        if (generationError) generationError.style.display = 'none';

        if (!progressList) return;

        progressList.innerHTML = this.processingSteps.map((step, index) => `
            <div class="progress-item" id="progress-${index}">
                <div class="item-content">
                    <div class="item-icon">
                        <i class="bi bi-circle"></i>
                    </div>
                    <div class="item-text">${step}</div>
                </div>
                <div class="item-status">Pending</div>
            </div>
        `).join('');
    }

    async executeProcessingStep(stepIndex) {
        const progressItem = document.getElementById(`progress-${stepIndex}`);
        if (!progressItem) return;

        // Mark as active
        progressItem.classList.add('active');
        progressItem.querySelector('.item-icon').innerHTML = '<div class="spinner-border spinner-border-sm"></div>';
        progressItem.querySelector('.item-status').textContent = 'Processing...';

        // Simulate processing time
        const processingTime = 2000 + Math.random() * 3000; // 2-5 seconds
        await this.delay(processingTime);

        // Mark as completed
        progressItem.classList.remove('active');
        progressItem.classList.add('completed');
        progressItem.querySelector('.item-icon').innerHTML = '<i class="bi bi-check"></i>';
        progressItem.querySelector('.item-status').textContent = 'Completed';

        // Update stats during processing
        if (stepIndex === 3) { // After content creation
            this.updateGenerationStats();
        }
    }

    updateGenerationStats() {
        const generationStats = document.getElementById('generation-stats');
        if (!generationStats) return;

        generationStats.style.display = 'block';

        const wordCount = this.appState.content.trim().split(/\s+/).length;
        const slideCount = Math.max(1, Math.ceil(wordCount / 150));
        const layoutCount = Math.min(slideCount, this.appState.templateAnalysis?.layouts.length || 4);
        const imageCount = this.appState.templateAnalysis?.images || 0;

        this.animateCounter('slides-generated', slideCount);
        this.animateCounter('words-processed', wordCount);
        this.animateCounter('layouts-applied', layoutCount);
        this.animateCounter('images-reused', imageCount);
    }

    animateCounter(elementId, targetValue) {
        const element = document.getElementById(elementId);
        if (!element) return;

        let current = 0;
        const increment = Math.ceil(targetValue / 20);
        const timer = setInterval(() => {
            current = Math.min(current + increment, targetValue);
            element.textContent = current.toLocaleString();
            
            if (current >= targetValue) {
                clearInterval(timer);
            }
        }, 50);
    }

    showGenerationComplete() {
        const generationComplete = document.getElementById('generation-complete');
        if (generationComplete) {
            generationComplete.style.display = 'block';
            generationComplete.classList.add('fade-in');
        }

        // Create mock presentation data
        this.appState.generatedPresentation = {
            filename: `presentation_${Date.now()}.pptx`,
            size: Math.floor(Math.random() * 5000000) + 1000000, // 1-5MB
            slideCount: Math.max(1, Math.ceil(this.appState.content.trim().split(/\s+/).length / 150))
        };

        this.showAlert('success', 'Your presentation has been generated successfully! Click download to get your file.');
    }

    showGenerationError(message) {
        const generationError = document.getElementById('generation-error');
        const errorMessage = document.getElementById('error-message');
        
        if (generationError) {
            generationError.style.display = 'block';
            generationError.classList.add('fade-in');
        }
        
        if (errorMessage) {
            errorMessage.textContent = message;
        }

        this.showAlert('danger', `Generation failed: ${message}`);
    }

    // Utility Functions
    updateNextButton(buttonId, enabled) {
        const button = document.getElementById(buttonId);
        if (button) {
            button.disabled = !enabled;
        }
    }

    downloadPresentation() {
        if (!this.appState.generatedPresentation) {
            this.showAlert('danger', 'No presentation available for download.');
            return;
        }

        // Create a mock file download
        const mockPptxData = this.createMockPptxData();
        const blob = new Blob([mockPptxData], { 
            type: 'application/vnd.openxmlformats-officedocument.presentationml.presentation' 
        });
        
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = this.appState.generatedPresentation.filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);

        this.showAlert('success', 'Presentation downloaded successfully!');
    }

    createMockPptxData() {
        // Create a simple text file with presentation info for demo purposes
        const content = `TextToSlides Generated Presentation
        
Generated: ${new Date().toLocaleString()}
Content Length: ${this.appState.content.length} characters
Guidance: ${this.appState.guidance || 'None provided'}
LLM Provider: ${this.appState.llmProvider}
Model: ${this.appState.llmModel}
Template: ${this.appState.template?.name || 'Unknown'}
Slides: ${this.appState.generatedPresentation?.slideCount || 0}

--- Content Preview ---
${this.appState.content.substring(0, 500)}${this.appState.content.length > 500 ? '...' : ''}

Note: This is a demo file. In a real implementation, this would be a proper PowerPoint file (.pptx) 
generated using libraries like python-pptx or similar tools.`;

        return content;
    }

    startOver() {
        // Reset application state
        this.appState = {
            content: '',
            guidance: '',
            llmProvider: null,
            llmModel: null,
            apiKey: '',
            template: null,
            templateAnalysis: null,
            generatedPresentation: null
        };

        // Clear form inputs
        const inputs = ['content-input', 'guidance-input', 'llm-provider', 'llm-model', 'api-key'];
        inputs.forEach(id => {
            const element = document.getElementById(id);
            if (element) element.value = '';
        });

        // Reset file upload
        this.removeTemplate();

        // Reset stats
        this.updateContentStats('');

        // Go back to step 1
        this.currentStep = 1;
        this.updateStepVisibility();
        this.updateProgressSteps();
        this.scrollToTop();

        this.showAlert('info', 'Application reset. You can start creating a new presentation!');
    }

    // Alert System
    showAlert(type, message, dismissible = true) {
        const alertContainer = document.getElementById('alert-container');
        if (!alertContainer) return;

        const alertId = `alert-${Date.now()}`;
        const alertHTML = `
            <div id="${alertId}" class="alert alert-${type} ${dismissible ? 'alert-dismissible' : ''} fade show" role="alert">
                ${message}
                ${dismissible ? `<button type="button" class="btn-close" onclick="document.getElementById('${alertId}').remove()"></button>` : ''}
            </div>
        `;

        alertContainer.insertAdjacentHTML('beforeend', alertHTML);

        // Auto-dismiss success messages
        if (type === 'success') {
            setTimeout(() => {
                const alert = document.getElementById(alertId);
                if (alert) alert.remove();
            }, 5000);
        }

        // Auto-dismiss info messages
        if (type === 'info') {
            setTimeout(() => {
                const alert = document.getElementById(alertId);
                if (alert) alert.remove();
            }, 8000);
        }
    }

    // Utility delay function
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM loaded, initializing app...');
    window.textToSlidesApp = new TextToSlidesApp();
});